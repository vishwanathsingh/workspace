<html>
<head>
<title>PHP Information</title>
</head>
<body bgcolor="#ffffff">
<? phpinfo() ?>
</body>
</html>
