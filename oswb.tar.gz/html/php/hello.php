<html>
<head>
<title>Hello, world! with PHP</title>
</head>
<body bgcolor="#ffffff">
<? echo "hello, world!" ?>
</body>
</html>
