<?
    function print_hello () {
        echo "hello, world!";
    }
?>
<html>
<head>
<title>PHP Functions - Part 1</title>
</head>
<body bgcolor="#ffffff">

<? print_hello(); ?>

</body>
</html>
