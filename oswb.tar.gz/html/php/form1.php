<html>
<head>
<title>PHP Form 1 Result</title>
</head>
<body bgcolor="#ffffff">
Using $var1: <b> <? echo $var1; ?> </b>
<br>
Using $var2: <b> <? echo $var2; ?> </b>
<br>
Using $HTTP_GET_VARS: 
<b> <? echo $HTTP_GET_VARS["var1"]; ?> </b>,
<b> <? echo $HTTP_GET_VARS["var2"]; ?> </b>
</body>
</html>
