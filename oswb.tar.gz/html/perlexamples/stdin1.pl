#! /usr/bin/perl -w
# file: stdin1.pl

use strict;
 
print "Enter your name: ";
 
my $name = <STDIN>;
 
print "Hello $name!\n";
