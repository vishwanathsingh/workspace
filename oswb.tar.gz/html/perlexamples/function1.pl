#! /usr/bin/perl -w
# file: function1.pl
 
sub say_hello {
    print "hello, world!\n";
}
 
say_hello();
