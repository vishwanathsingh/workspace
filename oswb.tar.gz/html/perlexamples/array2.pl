#! /usr/bin/perl -w
# file: array2.pl
 
use strict;

my @data = ('Joe', 39, 'Test data', 49.3);
 
print "element 0: $data[0]\n";
print "element 1: $data[1]\n";
print "element 2: $data[2]\n";
print "element 3: $data[3]\n";
