#! /usr/bin/perl -w
# file: simpleadd.pl

use strict;

my $a = 5;
my $b = 6;
my $c = $a + $b; 

print "\$c is now: $c\n"; 
