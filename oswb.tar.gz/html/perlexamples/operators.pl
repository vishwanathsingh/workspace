#! /usr/bin/perl -w
# file: operators.pl
 
use strict;

my $i = 10;
my $j = 4;
 
print '$i + $j = ', $i + $j, "\n";
print '$i * $j = ', $i * $j, "\n";
print '$i / $j = ', $i / $j, "\n";
print '$i % $j = ', $i % $j, "\n";
print '$i ** $j = ', $i ** $j, "\n";
