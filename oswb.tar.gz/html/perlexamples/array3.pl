#! /usr/bin/perl -w
# file: array3.pl
 
use strict;

my @data = ('Joe', 39, 'Test data', 49.3);
print "last index:  $#data\n";
