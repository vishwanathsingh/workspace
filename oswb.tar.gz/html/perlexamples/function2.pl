#! /usr/bin/perl -w
# file: function2.pl
 
say_hello();
 
sub say_hello {
    print "hello, world!\n";
}
