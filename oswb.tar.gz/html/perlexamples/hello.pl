#! /usr/bin/perl -w
# file: hello.pl

print "hello, world!\n";
